#pragma once

// ─── Credent backend ─────────────────────────────────────────────────────────
// The same Render backend the website and app use. The firmware talks to the
// /api/esp/* endpoints added in credent 2/backend.
//   POST /api/esp/register            -> { device_id, device_token, pairing_code }
//   GET  /api/esp/config/:deviceId    -> { status, paired, config }   (x-device-token)
#define CREDENT_API_BASE "https://credent-backend.onrender.com"

// ─── Wi-Fi captive portal ────────────────────────────────────────────────────
// SSID the device broadcasts for first-time setup (matches site/esp-source.json
// and the website pairing instructions).
#define CREDENT_SETUP_SSID "Credent-Mino"
#define CREDENT_SETUP_PASS ""   // open hotspot; empty = no password

// ─── Pairing config poll ─────────────────────────────────────────────────────
#define CONFIG_POLL_INTERVAL_MS 5000   // how often to poll config while unpaired
#define CONFIG_POLL_INTERVAL_PAIRED_MS 60000  // slower once paired

// ─── Hardware (DFRobot ESP32-S3 AI Cam) ──────────────────────────────────────
// Onboard LED used as a simple pairing-status indicator.
//   slow blink  = waiting for Wi-Fi / setup
//   fast blink  = registered, waiting to be paired (code is being spoken)
//   solid on    = paired
#define STATUS_LED_GPIO 3

// ─── Phase 2: voice loop ─────────────────────────────────────────────────────
// WebSocket endpoint of the Credent voice server. Default to the API host on
// the voice port; override per-deployment. (ws:// for dev; use wss:// + a TLS
// build for production.)
#define CREDENT_VOICE_WS_HOST "credent-backend.onrender.com"
#define CREDENT_VOICE_WS_PORT 8765
#define CREDENT_VOICE_WS_PATH "/"

// Audio format on the wire — MUST match the voice server (config.py).
#define AUDIO_SAMPLE_RATE 16000   // Hz, mono
#define AUDIO_FRAME_MS    20      // ms per frame sent to the server
#define AUDIO_FRAME_SAMPLES (AUDIO_SAMPLE_RATE / 1000 * AUDIO_FRAME_MS) // 320

// Wire codec — MUST match the server's CREDENT_AUDIO_CODEC.
//   0 = raw PCM (LAN testing)   1 = Opus (bandwidth-efficient for real networks)
#define AUDIO_USE_OPUS 1
// Max bytes an encoded Opus frame can produce (generous headroom for 20ms).
#define OPUS_MAX_PACKET 256

// ─── I2S pins (DFRobot ESP32-S3 AI Cam) ──────────────────────────────────────
// Speaker via MAX98357A — these are fixed by the board design (Phase 1 facts):
#define I2S_SPK_BCLK_GPIO 45
#define I2S_SPK_LRC_GPIO  46
#define I2S_SPK_DIN_GPIO  42
// Onboard PDM microphone — two dedicated pins on this board:
#define I2S_MIC_CLK_GPIO  39
#define I2S_MIC_DATA_GPIO 40
