// Credent Mino — audio I/O (Phase 2).
// Mic capture via the onboard PDM microphone; speaker playback via the
// MAX98357A I2S amplifier. All audio is 16-bit signed PCM, mono,
// AUDIO_SAMPLE_RATE Hz — the format the voice server expects.
#pragma once
#include <Arduino.h>

namespace audio {

// Bring up both I2S peripherals (mic in, speaker out). Returns false on failure.
bool begin();

// Read exactly AUDIO_FRAME_SAMPLES of PCM from the mic into `out` (which must
// hold AUDIO_FRAME_SAMPLES int16). Returns the number of samples read.
size_t readFrame(int16_t *out);

// Play a buffer of PCM samples on the speaker (blocks until queued).
void play(const int16_t *pcm, size_t samples);

} // namespace audio
