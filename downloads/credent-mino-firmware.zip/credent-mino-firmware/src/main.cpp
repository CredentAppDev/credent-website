// ============================================================================
//  Credent Mino firmware — Phase 1 (pairing + live config)
//  Board: DFRobot ESP32-S3 AI Cam
//
//  Flow:
//    1. Bring up Wi-Fi via a captive portal hotspot ("Credent-Mino").
//    2. POST /api/esp/register  -> get device_id, device_token, pairing_code.
//    3. "Speak" / show the pairing code so the user can type it on
//       credentgh.com/esp-pair.html  (no account needed).
//    4. Poll GET /api/esp/config/:device_id (auth: x-device-token) until the
//       backend reports status == "paired", then apply the config manifest.
//
//  Phase 2 (here): once paired, bring up I2S audio and open a WebSocket to the
//  Credent voice server — mic -> Opus -> WS -> (server: ASR -> Emrys/Claude ->
//  TTS) -> WS -> Opus -> speaker. Device tools (set_led, etc.) arrive as
//  control messages. Audio is Opus by default (AUDIO_USE_OPUS in config.h);
//  set it to 0 for raw PCM on a LAN. Must match the server's CREDENT_AUDIO_CODEC.
// ============================================================================

#include <Arduino.h>
#include <WiFi.h>
#include <WiFiManager.h>
#include <HTTPClient.h>
#include <ArduinoJson.h>
#include "config.h"
#include "audio.h"
#include "voice.h"

// ─── Device state ────────────────────────────────────────────────────────────
static long   gDeviceId = 0;
static String gDeviceToken;
static String gPairingCode;
static bool   gPaired = false;

// ─── Helpers ─────────────────────────────────────────────────────────────────

// A stable per-board id derived from the eFuse MAC. The backend keys devices on
// this, so the same board re-registering keeps its identity (and device_token).
static String hardwareId() {
  uint64_t mac = ESP.getEfuseMac();
  char buf[24];
  snprintf(buf, sizeof(buf), "mino-%012llX", mac);
  return String(buf);
}

// Stand-in for the speaker/TTS that arrives in Phase 2. For now we make the
// pairing code obvious over serial (and could drive the onboard LED to blink
// the digits). Real audio playback is intentionally out of scope here.
static void speakPairingCode(const String &code) {
  Serial.println();
  Serial.println("  ┌────────────────────────────────────────────┐");
  Serial.printf ("  │  Say this on credentgh.com/esp-pair.html:   │\n");
  Serial.printf ("  │              PAIRING CODE  %s            │\n", code.c_str());
  Serial.println("  └────────────────────────────────────────────┘");
  Serial.println();
}

// POST /api/esp/register  — returns true on success and fills global state.
static bool registerWithCredent() {
  HTTPClient http;
  http.begin(String(CREDENT_API_BASE) + "/api/esp/register");
  http.addHeader("Content-Type", "application/json");

  StaticJsonDocument<128> body;
  body["hardware_id"] = hardwareId();
  String payload;
  serializeJson(body, payload);

  int status = http.POST(payload);
  if (status != 200) {
    Serial.printf("[register] HTTP %d\n", status);
    http.end();
    return false;
  }

  StaticJsonDocument<512> doc;
  DeserializationError err = deserializeJson(doc, http.getString());
  http.end();
  if (err) {
    Serial.printf("[register] JSON parse error: %s\n", err.c_str());
    return false;
  }

  gDeviceId    = doc["device_id"] | 0;
  gDeviceToken = String((const char *)(doc["device_token"] | ""));
  gPairingCode = String((const char *)(doc["pairing_code"] | ""));

  if (!gDeviceId || gDeviceToken.isEmpty() || gPairingCode.isEmpty()) {
    Serial.println("[register] missing fields in response");
    return false;
  }

  Serial.printf("[register] device_id=%ld\n", gDeviceId);
  return true;
}

// GET /api/esp/config/:device_id  — returns true when the device is paired and
// applies the config manifest.
static bool pollConfig() {
  HTTPClient http;
  http.begin(String(CREDENT_API_BASE) + "/api/esp/config/" + String(gDeviceId));
  http.addHeader("x-device-token", gDeviceToken);

  int status = http.GET();
  if (status != 200) {
    Serial.printf("[config] HTTP %d\n", status);
    http.end();
    return false;
  }

  StaticJsonDocument<1024> doc;
  DeserializationError err = deserializeJson(doc, http.getString());
  http.end();
  if (err) {
    Serial.printf("[config] JSON parse error: %s\n", err.c_str());
    return false;
  }

  bool paired = doc["paired"] | false;
  if (!paired) return false;

  // Apply the live manifest. Phase 2 will consume these to open the voice loop.
  JsonObject cfg = doc["config"].as<JsonObject>();
  Serial.println("[config] PAIRED — applying Credent manifest:");
  Serial.printf("  assistantSource : %s\n", (const char *)(cfg["assistantSource"] | "?"));
  Serial.printf("  voice           : %s\n", (const char *)(cfg["voice"] | "?"));
  Serial.printf("  model           : %s\n", (const char *)(cfg["model"] | "?"));
  Serial.printf("  mcpToolsEnabled : %s\n", (cfg["mcpToolsEnabled"] | false) ? "yes" : "no");
  return true;
}

// ─── Arduino lifecycle ───────────────────────────────────────────────────────
void setup() {
  Serial.begin(115200);
  delay(300);
  pinMode(STATUS_LED_GPIO, OUTPUT);

  Serial.println("\nCredent Mino — Phase 1 boot");
  Serial.printf("hardware_id: %s\n", hardwareId().c_str());

  // Captive portal: join "Credent-Mino", open the page, enter home Wi-Fi.
  WiFiManager wm;
  wm.setConfigPortalTimeout(180);
  bool ok = wm.autoConnect(CREDENT_SETUP_SSID,
                           strlen(CREDENT_SETUP_PASS) ? CREDENT_SETUP_PASS : nullptr);
  if (!ok) {
    Serial.println("[wifi] setup timed out — restarting");
    delay(1000);
    ESP.restart();
  }
  Serial.printf("[wifi] connected, ip=%s\n", WiFi.localIP().toString().c_str());

  // Register and announce the pairing code.
  while (!registerWithCredent()) {
    Serial.println("[register] retrying in 5s…");
    delay(5000);
  }
  speakPairingCode(gPairingCode);
}

static bool gVoiceStarted = false;

void loop() {
  if (gPaired) {
    digitalWrite(STATUS_LED_GPIO, HIGH);   // solid = paired

    // Phase 2: start the live voice loop once, then pump it every loop.
    if (!gVoiceStarted) {
      if (audio::begin()) {
        voice::begin(gDeviceId, gDeviceToken);
        gVoiceStarted = true;
        Serial.println("[mino] voice loop started — talk to Emrys");
      } else {
        Serial.println("[mino] audio init failed; retrying shortly");
        delay(2000);
        return;
      }
    }
    voice::poll();   // pumps WebSocket + streams a mic frame; non-blocking
    return;
  }

  // Fast blink while waiting to be paired.
  digitalWrite(STATUS_LED_GPIO, millis() / 250 % 2);

  if (pollConfig()) {
    gPaired = true;
    Serial.println("[mino] paired — bringing up the voice loop");
  }
  delay(CONFIG_POLL_INTERVAL_MS);
}
