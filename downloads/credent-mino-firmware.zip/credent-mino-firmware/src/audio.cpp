#include "audio.h"
#include "config.h"
#include <driver/i2s.h>

// Two I2S ports: one for the PDM mic (RX), one for the MAX98357A speaker (TX).
#define I2S_MIC_PORT I2S_NUM_0
#define I2S_SPK_PORT I2S_NUM_1

namespace audio {

static bool startMic() {
  i2s_config_t cfg = {};
  cfg.mode = (i2s_mode_t)(I2S_MODE_MASTER | I2S_MODE_RX | I2S_MODE_PDM);
  cfg.sample_rate = AUDIO_SAMPLE_RATE;
  cfg.bits_per_sample = I2S_BITS_PER_SAMPLE_16BIT;
  cfg.channel_format = I2S_CHANNEL_FMT_ONLY_LEFT;
  cfg.communication_format = I2S_COMM_FORMAT_STAND_I2S;
  cfg.intr_alloc_flags = ESP_INTR_FLAG_LEVEL1;
  cfg.dma_buf_count = 4;
  cfg.dma_buf_len = AUDIO_FRAME_SAMPLES;
  cfg.use_apll = false;

  if (i2s_driver_install(I2S_MIC_PORT, &cfg, 0, nullptr) != ESP_OK) return false;

  i2s_pin_config_t pins = {};
  pins.bck_io_num = I2S_PIN_NO_CHANGE;
  pins.ws_io_num = I2S_MIC_CLK_GPIO;   // PDM clock
  pins.data_out_num = I2S_PIN_NO_CHANGE;
  pins.data_in_num = I2S_MIC_DATA_GPIO; // PDM data
  return i2s_set_pin(I2S_MIC_PORT, &pins) == ESP_OK;
}

static bool startSpeaker() {
  i2s_config_t cfg = {};
  cfg.mode = (i2s_mode_t)(I2S_MODE_MASTER | I2S_MODE_TX);
  cfg.sample_rate = AUDIO_SAMPLE_RATE;
  cfg.bits_per_sample = I2S_BITS_PER_SAMPLE_16BIT;
  cfg.channel_format = I2S_CHANNEL_FMT_ONLY_LEFT;
  cfg.communication_format = I2S_COMM_FORMAT_STAND_I2S;
  cfg.intr_alloc_flags = ESP_INTR_FLAG_LEVEL1;
  cfg.dma_buf_count = 6;
  cfg.dma_buf_len = AUDIO_FRAME_SAMPLES;
  cfg.use_apll = false;

  if (i2s_driver_install(I2S_SPK_PORT, &cfg, 0, nullptr) != ESP_OK) return false;

  i2s_pin_config_t pins = {};
  pins.bck_io_num = I2S_SPK_BCLK_GPIO;
  pins.ws_io_num = I2S_SPK_LRC_GPIO;
  pins.data_out_num = I2S_SPK_DIN_GPIO;
  pins.data_in_num = I2S_PIN_NO_CHANGE;
  return i2s_set_pin(I2S_SPK_PORT, &pins) == ESP_OK;
}

bool begin() {
  if (!startMic()) { Serial.println("[audio] mic init failed"); return false; }
  if (!startSpeaker()) { Serial.println("[audio] speaker init failed"); return false; }
  Serial.println("[audio] mic + speaker ready");
  return true;
}

size_t readFrame(int16_t *out) {
  size_t bytesRead = 0;
  i2s_read(I2S_MIC_PORT, out, AUDIO_FRAME_SAMPLES * sizeof(int16_t),
           &bytesRead, portMAX_DELAY);
  return bytesRead / sizeof(int16_t);
}

void play(const int16_t *pcm, size_t samples) {
  size_t bytesWritten = 0;
  i2s_write(I2S_SPK_PORT, pcm, samples * sizeof(int16_t),
            &bytesWritten, portMAX_DELAY);
}

} // namespace audio
