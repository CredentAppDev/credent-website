#include "voice.h"
#include "audio.h"
#include "config.h"
#include <WebSocketsClient.h>
#include <ArduinoJson.h>
#if AUDIO_USE_OPUS
#include <opus.h>
#endif

namespace voice {

static WebSocketsClient ws;
static long gDeviceId = 0;
static String gDeviceToken;
static bool gReady = false;

#if AUDIO_USE_OPUS
// Opus encoder (mic → wire) and decoder (wire → speaker). One frame = 20ms.
static OpusEncoder *gEnc = nullptr;
static OpusDecoder *gDec = nullptr;

static void opusBegin() {
  int err = 0;
  gEnc = opus_encoder_create(AUDIO_SAMPLE_RATE, 1, OPUS_APPLICATION_VOIP, &err);
  if (err != OPUS_OK) Serial.printf("[voice] opus enc init err %d\n", err);
  gDec = opus_decoder_create(AUDIO_SAMPLE_RATE, 1, &err);
  if (err != OPUS_OK) Serial.printf("[voice] opus dec init err %d\n", err);
}
#endif

// Forward decl — device action handler (set_led / read_sensor).
static String runDeviceCommand(const String &tool, JsonObjectConst input);

static void sendHello() {
  StaticJsonDocument<192> doc;
  doc["type"] = "hello";
  doc["device_id"] = gDeviceId;
  doc["device_token"] = gDeviceToken;
  String out;
  serializeJson(doc, out);
  ws.sendTXT(out);
}

// Reply to a device_command with its result so Emrys can continue the turn.
static void sendDeviceResult(const char *id, const String &result) {
  StaticJsonDocument<256> doc;
  doc["type"] = "device_result";
  doc["id"] = id;
  doc["result"] = result;
  String out;
  serializeJson(doc, out);
  ws.sendTXT(out);
}

static void onText(uint8_t *payload, size_t len) {
  StaticJsonDocument<512> doc;
  if (deserializeJson(doc, payload, len)) return;
  const char *type = doc["type"] | "";

  if (strcmp(type, "ready") == 0) {
    gReady = true;
    Serial.println("[voice] server ready — streaming mic");
  } else if (strcmp(type, "error") == 0) {
    gReady = false;
    Serial.printf("[voice] server error: %s\n", (const char *)(doc["message"] | "?"));
  } else if (strcmp(type, "device_command") == 0) {
    const char *id = doc["id"] | "";
    const char *tool = doc["tool"] | "";
    String result = runDeviceCommand(tool, doc["input"].as<JsonObjectConst>());
    sendDeviceResult(id, result);
  }
}

static void onEvent(WStype_t type, uint8_t *payload, size_t len) {
  switch (type) {
    case WStype_CONNECTED:
      Serial.println("[voice] connected — sending hello");
      gReady = false;
      sendHello();
      break;
    case WStype_DISCONNECTED:
      Serial.println("[voice] disconnected");
      gReady = false;
      break;
    case WStype_TEXT:
      onText(payload, len);
      break;
    case WStype_BIN: {
      // Inbound speaker audio.
#if AUDIO_USE_OPUS
      // Decode one Opus frame → PCM, then play.
      static int16_t pcm[AUDIO_FRAME_SAMPLES];
      int n = opus_decode(gDec, payload, len, pcm, AUDIO_FRAME_SAMPLES, 0);
      if (n > 0) audio::play(pcm, n);
#else
      audio::play(reinterpret_cast<int16_t *>(payload), len / sizeof(int16_t));
#endif
      break;
    }
    default:
      break;
  }
}

void begin(long deviceId, const String &deviceToken) {
  gDeviceId = deviceId;
  gDeviceToken = deviceToken;
#if AUDIO_USE_OPUS
  opusBegin();
#endif
  ws.begin(CREDENT_VOICE_WS_HOST, CREDENT_VOICE_WS_PORT, CREDENT_VOICE_WS_PATH);
  ws.onEvent(onEvent);
  ws.setReconnectInterval(3000);
}

void poll() {
  ws.loop();
  if (!gReady) return;

  // Stream one mic frame per poll.
  static int16_t frame[AUDIO_FRAME_SAMPLES];
  size_t n = audio::readFrame(frame);
  if (n == AUDIO_FRAME_SAMPLES) {
#if AUDIO_USE_OPUS
    // Encode the 20ms PCM frame to Opus, then send the compact packet.
    static uint8_t pkt[OPUS_MAX_PACKET];
    int bytes = opus_encode(gEnc, frame, AUDIO_FRAME_SAMPLES, pkt, OPUS_MAX_PACKET);
    if (bytes > 0) ws.sendBIN(pkt, bytes);
#else
    ws.sendBIN(reinterpret_cast<uint8_t *>(frame), n * sizeof(int16_t));
#endif
  }
}

bool isReady() { return gReady; }

// ─── Device actions Emrys can trigger ────────────────────────────────────────
static String runDeviceCommand(const String &tool, JsonObjectConst input) {
  if (tool == "set_led") {
    const char *state = input["state"] | "off";
    bool on = (strcmp(state, "on") == 0);
    digitalWrite(STATUS_LED_GPIO, on ? HIGH : LOW);
    return on ? "LED turned on." : "LED turned off.";
  }
  if (tool == "read_sensor") {
    // Placeholder — wire to a real sensor in your build.
    return "Sensor reading not available on this build.";
  }
  return String("Unknown device tool: ") + tool;
}

} // namespace voice
