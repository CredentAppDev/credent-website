// Credent Mino — voice loop client (Phase 2).
// Opens a WebSocket to the Credent voice server, authenticates with the
// device's pairing identity, streams mic audio up, and plays speaker audio
// down. Also handles device_command messages (e.g. set_led) Emrys sends.
#pragma once
#include <Arduino.h>

namespace voice {

// Connect to the voice server and send the `hello` handshake using the identity
// obtained during Phase 1 pairing.
void begin(long deviceId, const String &deviceToken);

// Pump the WebSocket + stream one mic frame if connected & ready. Call often
// from loop().
void poll();

// True once the server has accepted the handshake (replied "ready").
bool isReady();

} // namespace voice
