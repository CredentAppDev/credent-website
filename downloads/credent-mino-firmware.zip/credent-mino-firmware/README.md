# Credent Mino firmware

Credent's own ESP32-S3 firmware for the **Mino** voice assistant — the start of
replacing the third-party **xiaozhi.me** console with Credent's own pairing,
config, and (later) voice pipeline.

Board: **DFRobot ESP32-S3 AI Cam**.

## Status

**Phase 1 — pairing + live config** ✅

```
boot → Wi-Fi captive portal ("Credent-Mino") → POST /api/esp/register
     → speak 6-digit pairing code → user enters it at
       credentgh.com/esp-pair.html (no account needed)
     → poll GET /api/esp/config/:id until paired → apply Credent manifest
```

**Phase 2 — live voice loop** ✅ (audio + WebSocket built; Opus codec TODO)

```
paired → audio::begin() (I2S mic + MAX98357A speaker)
       → WebSocket to the Credent voice server → hello handshake (device_id + token)
       → stream mic PCM up  →  server: ASR → Emrys/Claude → TTS  →  speaker PCM down
       → Emrys device_command messages (set_led, …) handled on-device
```

The backend endpoints live in `credent 2/backend` (`/api/esp/*`), the pairing
page is `credent-website/esp-pair.html`, and the voice server is the
`credent-voice-server` repo.

### Phase 2 source layout
- `src/audio.{h,cpp}` — I2S mic capture (PDM) + speaker playback (MAX98357A)
- `src/voice.{h,cpp}` — WebSocket client, handshake, audio streaming, device commands
- Config in `include/config.h` → `CREDENT_VOICE_WS_*`, `AUDIO_*`, `I2S_*` pins

### Audio codec
Opus is on by default (`AUDIO_USE_OPUS 1` in `include/config.h`) — mic frames are
Opus-encoded before sending and inbound frames Opus-decoded before playback.
Set `AUDIO_USE_OPUS 0` for raw PCM on a trusted LAN. **Must match the server's
`CREDENT_AUDIO_CODEC`** (`opus` ↔ 1, `pcm` ↔ 0).

## Build & flash

Requires [PlatformIO](https://platformio.org/).

```bash
pio run                  # build
pio run -t upload        # flash over USB-C
pio device monitor       # watch serial — the pairing code prints here
```

## Config

Edit `include/config.h`:

| Setting | Default | Notes |
|---|---|---|
| `CREDENT_API_BASE` | `https://credent-backend.onrender.com` | Same backend the website/app use |
| `CREDENT_SETUP_SSID` | `Credent-Mino` | Setup hotspot name |
| `STATUS_LED_GPIO` | `3` | Onboard LED — slow blink = setup, fast = awaiting pair, solid = paired |

## Notes

- The device identifies itself by a MAC-derived `hardware_id`, so re-flashing or
  power-cycling keeps its identity and `device_token`.
- The pairing code expires after 10 minutes; power-cycle for a fresh one.
- For local backend testing, point `CREDENT_API_BASE` at your machine
  (e.g. `http://192.168.x.x:5000`).
